-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 03, 2017 at 11:37 AM
-- Server version: 5.7.16-log
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `referentiel`
--

-- --------------------------------------------------------

--
-- Table structure for table `adresse`
--

CREATE TABLE `adresse` (
  `id` int(11) NOT NULL,
  `rue` varchar(45) DEFAULT NULL,
  `cp` varchar(45) DEFAULT NULL,
  `ville` varchar(45) DEFAULT NULL,
  `telephone1` varchar(45) DEFAULT NULL,
  `telephone2` varchar(45) DEFAULT NULL,
  `fax` varchar(45) DEFAULT NULL,
  `portable` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `Pays_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `adresse`
--

INSERT INTO `adresse` (`id`, `rue`, `cp`, `ville`, `telephone1`, `telephone2`, `fax`, `portable`, `email`, `Pays_id`) VALUES
(13, NULL, '92100', 'Boulogne', NULL, NULL, NULL, NULL, NULL, 20),
(14, NULL, '92100', 'Meudon', NULL, NULL, NULL, NULL, NULL, 20),
(15, NULL, '92200', 'Clamart', NULL, NULL, NULL, NULL, NULL, 20);

-- --------------------------------------------------------

--
-- Table structure for table `document`
--

CREATE TABLE `document` (
  `id` int(11) NOT NULL,
  `nom` varchar(45) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `date_upload` datetime DEFAULT NULL,
  `Personnel_id` int(11) NOT NULL,
  `TypeDocument_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `enseigne`
--

CREATE TABLE `enseigne` (
  `id` int(11) NOT NULL,
  `nom` varchar(45) DEFAULT NULL,
  `logo` varchar(45) DEFAULT NULL,
  `libelle_court` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `enseigne`
--

INSERT INTO `enseigne` (`id`, `nom`, `logo`, `libelle_court`) VALUES
(3, 'Frank Provost', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `groupe`
--

CREATE TABLE `groupe` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `langue`
--

CREATE TABLE `langue` (
  `id` int(11) NOT NULL,
  `nom` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pays`
--

CREATE TABLE `pays` (
  `id` int(11) NOT NULL,
  `nom` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pays`
--

INSERT INTO `pays` (`id`, `nom`) VALUES
(19, 'Allemagne'),
(20, 'France');

-- --------------------------------------------------------

--
-- Table structure for table `pays_has_langue`
--

CREATE TABLE `pays_has_langue` (
  `Pays_id` int(11) NOT NULL,
  `Langue_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `personnel`
--

CREATE TABLE `personnel` (
  `id` int(11) NOT NULL,
  `nom` varchar(45) DEFAULT NULL,
  `prenom` varchar(45) DEFAULT NULL,
  `date_embauche` datetime DEFAULT NULL,
  `date_fin_contrat` datetime DEFAULT NULL,
  `type_contrat` varchar(45) DEFAULT NULL,
  `actif` tinyint(1) DEFAULT NULL,
  `Adresse_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `personnel`
--

INSERT INTO `personnel` (`id`, `nom`, `prenom`, `date_embauche`, `date_fin_contrat`, `type_contrat`, `actif`, `Adresse_id`) VALUES
(4, 'Bernard', 'MINET', NULL, NULL, NULL, 1, 14),
(5, 'Stépahne', 'DESCHAMPS', NULL, NULL, NULL, 1, 15);

-- --------------------------------------------------------

--
-- Table structure for table `personnel_has_profession`
--

CREATE TABLE `personnel_has_profession` (
  `Personnel_id` int(11) NOT NULL,
  `Profession_id` int(11) NOT NULL,
  `date_debut` datetime DEFAULT NULL,
  `date_fin` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `personnel_has_profession`
--

INSERT INTO `personnel_has_profession` (`Personnel_id`, `Profession_id`, `date_debut`, `date_fin`) VALUES
(4, 3, NULL, NULL),
(5, 4, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `personnel_has_salon`
--

CREATE TABLE `personnel_has_salon` (
  `Personnel_id` int(11) NOT NULL,
  `Salon_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `profession`
--

CREATE TABLE `profession` (
  `id` int(11) NOT NULL,
  `nom` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `profession`
--

INSERT INTO `profession` (`id`, `nom`) VALUES
(3, 'manager'),
(4, 'service paie');

-- --------------------------------------------------------

--
-- Table structure for table `responsable_r`
--

CREATE TABLE `responsable_r` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) DEFAULT NULL,
  `prenom` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `salon`
--

CREATE TABLE `salon` (
  `id` int(11) NOT NULL,
  `nom` varchar(45) DEFAULT NULL,
  `code_interne` varchar(45) DEFAULT NULL,
  `siret` varchar(45) DEFAULT NULL,
  `date_creation` varchar(45) DEFAULT NULL,
  `date_fermeture` varchar(45) DEFAULT NULL,
  `marque` varchar(45) DEFAULT NULL,
  `langue_defaut` varchar(45) DEFAULT NULL,
  `Enseigne_id` int(11) NOT NULL,
  `Adresse_id` int(11) NOT NULL,
  `Groupe_id` int(11) DEFAULT NULL,
  `marlix` varchar(255) DEFAULT NULL,
  `sage_paie` int(255) DEFAULT NULL,
  `responsable_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `salon`
--

INSERT INTO `salon` (`id`, `nom`, `code_interne`, `siret`, `date_creation`, `date_fermeture`, `marque`, `langue_defaut`, `Enseigne_id`, `Adresse_id`, `Groupe_id`, `marlix`, `sage_paie`, `responsable_id`) VALUES
(3, 'BOULOGNE', NULL, '152464BE6', NULL, NULL, NULL, NULL, 3, 13, NULL, '3', 57901, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `typedocument`
--

CREATE TABLE `typedocument` (
  `id` int(11) NOT NULL,
  `nom` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adresse`
--
ALTER TABLE `adresse`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_Adresse_Pays1_idx` (`Pays_id`);

--
-- Indexes for table `document`
--
ALTER TABLE `document`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_Document_Personnel1_idx` (`Personnel_id`),
  ADD KEY `fk_Document_TypeDocument1_idx` (`TypeDocument_id`);

--
-- Indexes for table `enseigne`
--
ALTER TABLE `enseigne`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groupe`
--
ALTER TABLE `groupe`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `langue`
--
ALTER TABLE `langue`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pays`
--
ALTER TABLE `pays`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pays_has_langue`
--
ALTER TABLE `pays_has_langue`
  ADD PRIMARY KEY (`Pays_id`,`Langue_id`),
  ADD KEY `fk_Pays_has_Langue_Langue1_idx` (`Langue_id`),
  ADD KEY `fk_Pays_has_Langue_Pays1_idx` (`Pays_id`);

--
-- Indexes for table `personnel`
--
ALTER TABLE `personnel`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_Personnel_Adresse1_idx` (`Adresse_id`);

--
-- Indexes for table `personnel_has_profession`
--
ALTER TABLE `personnel_has_profession`
  ADD PRIMARY KEY (`Personnel_id`,`Profession_id`),
  ADD KEY `fk_Personnel_has_Profession_Profession1_idx` (`Profession_id`),
  ADD KEY `fk_Personnel_has_Profession_Personnel1_idx` (`Personnel_id`);

--
-- Indexes for table `personnel_has_salon`
--
ALTER TABLE `personnel_has_salon`
  ADD PRIMARY KEY (`Personnel_id`,`Salon_id`),
  ADD KEY `fk_Personnel_has_Salon_Salon1_idx` (`Salon_id`),
  ADD KEY `fk_Personnel_has_Salon_Personnel_idx` (`Personnel_id`);

--
-- Indexes for table `profession`
--
ALTER TABLE `profession`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `responsable_r`
--
ALTER TABLE `responsable_r`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salon`
--
ALTER TABLE `salon`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_Salon_Enseigne1_idx` (`Enseigne_id`),
  ADD KEY `fk_Salon_Adresse1_idx` (`Adresse_id`),
  ADD KEY `fk_Salon_Groupe1_idx` (`Groupe_id`),
  ADD KEY `responsable_id` (`responsable_id`);

--
-- Indexes for table `typedocument`
--
ALTER TABLE `typedocument`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adresse`
--
ALTER TABLE `adresse`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `document`
--
ALTER TABLE `document`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `enseigne`
--
ALTER TABLE `enseigne`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `groupe`
--
ALTER TABLE `groupe`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `langue`
--
ALTER TABLE `langue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pays`
--
ALTER TABLE `pays`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `personnel`
--
ALTER TABLE `personnel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `profession`
--
ALTER TABLE `profession`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `responsable_r`
--
ALTER TABLE `responsable_r`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `salon`
--
ALTER TABLE `salon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `typedocument`
--
ALTER TABLE `typedocument`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `adresse`
--
ALTER TABLE `adresse`
  ADD CONSTRAINT `fk_Adresse_Pays1` FOREIGN KEY (`Pays_id`) REFERENCES `pays` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `document`
--
ALTER TABLE `document`
  ADD CONSTRAINT `fk_Document_Personnel1` FOREIGN KEY (`Personnel_id`) REFERENCES `personnel` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Document_TypeDocument1` FOREIGN KEY (`TypeDocument_id`) REFERENCES `typedocument` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `pays_has_langue`
--
ALTER TABLE `pays_has_langue`
  ADD CONSTRAINT `fk_Pays_has_Langue_Langue1` FOREIGN KEY (`Langue_id`) REFERENCES `langue` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Pays_has_Langue_Pays1` FOREIGN KEY (`Pays_id`) REFERENCES `pays` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `personnel`
--
ALTER TABLE `personnel`
  ADD CONSTRAINT `fk_Personnel_Adresse1` FOREIGN KEY (`Adresse_id`) REFERENCES `adresse` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `personnel_has_profession`
--
ALTER TABLE `personnel_has_profession`
  ADD CONSTRAINT `fk_Personnel_has_Profession_Personnel1` FOREIGN KEY (`Personnel_id`) REFERENCES `personnel` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Personnel_has_Profession_Profession1` FOREIGN KEY (`Profession_id`) REFERENCES `profession` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `personnel_has_salon`
--
ALTER TABLE `personnel_has_salon`
  ADD CONSTRAINT `fk_Personnel_has_Salon_Personnel` FOREIGN KEY (`Personnel_id`) REFERENCES `personnel2` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Personnel_has_Salon_Salon1` FOREIGN KEY (`Salon_id`) REFERENCES `salon2` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `salon`
--
ALTER TABLE `salon`
  ADD CONSTRAINT `fk_Salon_Adresse1` FOREIGN KEY (`Adresse_id`) REFERENCES `adresse` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Salon_Enseigne1` FOREIGN KEY (`Enseigne_id`) REFERENCES `enseigne` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Salon_Groupe1` FOREIGN KEY (`Groupe_id`) REFERENCES `groupe` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `salon_ibfk_1` FOREIGN KEY (`responsable_id`) REFERENCES `responsable_r` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
